/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 sasuke sasuke.png 
 * Time-stamp: Tuesday 04/04/2023, 23:03:12
 * 
 * Image Information
 * -----------------
 * sasuke.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SASUKE_H
#define SASUKE_H

extern const unsigned short sasuke[400];
#define SASUKE_SIZE 800
#define SASUKE_LENGTH 400
#define SASUKE_WIDTH 20
#define SASUKE_HEIGHT 20

#endif

