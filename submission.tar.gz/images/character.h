/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 character character.png 
 * Time-stamp: Tuesday 04/04/2023, 23:03:01
 * 
 * Image Information
 * -----------------
 * character.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHARACTER_H
#define CHARACTER_H

extern const unsigned short character[400];
#define CHARACTER_SIZE 800
#define CHARACTER_LENGTH 400
#define CHARACTER_WIDTH 20
#define CHARACTER_HEIGHT 20

#endif

