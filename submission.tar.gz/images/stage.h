/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 stage stage.jpeg 
 * Time-stamp: Tuesday 04/04/2023, 09:39:07
 * 
 * Image Information
 * -----------------
 * stage.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAGE_H
#define STAGE_H

extern const unsigned short stage[38400];
#define STAGE_SIZE 76800
#define STAGE_LENGTH 38400
#define STAGE_WIDTH 240
#define STAGE_HEIGHT 160

#endif

