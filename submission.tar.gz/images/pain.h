/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 pain pain.png 
 * Time-stamp: Tuesday 04/04/2023, 23:03:20
 * 
 * Image Information
 * -----------------
 * pain.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PAIN_H
#define PAIN_H

extern const unsigned short pain[400];
#define PAIN_SIZE 800
#define PAIN_LENGTH 400
#define PAIN_WIDTH 20
#define PAIN_HEIGHT 20

#endif

